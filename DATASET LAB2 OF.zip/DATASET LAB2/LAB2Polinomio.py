import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler, PolynomialFeatures
import matplotlib.pyplot as plt

# Cargar el dataset
file_path = "D:/DATASET LAB2/data.csv"
data = pd.read_csv(file_path)

# Mostrar las primeras filas para entender la estructura
print(data.head())
print(f"Dimensiones de X: {data.shape}")

# Convertir variables categóricas a variables dummy (One-Hot Encoding)
data = pd.get_dummies(data, drop_first=True)

# Separar las características (X) y la variable objetivo (y)
X = data.drop('Income', axis=1).values
y = data['Income'].values

# Generar características polinómicas
grado_polinomio = 2  # Puedes cambiar el grado del polinomio aquí
poly = PolynomialFeatures(degree=grado_polinomio)
X_poly = poly.fit_transform(X)

# Normalizar las características polinómicas
scaler = StandardScaler()
X_norm = scaler.fit_transform(X_poly)

print(f"Dimensiones de X normalizadas: {X_norm.shape}")
print(f"Dimensiones de y: {y.shape}")

# Añadir una columna de unos para el término de sesgo (bias)
X_ready = np.concatenate([np.ones((X_norm.shape[0], 1)), X_norm], axis=1)

# Función para calcular el costo
def calcularCosto(X, y, theta):
    m = y.size
    J = (1/(2 * m)) * np.sum(np.square(np.dot(X, theta) - y))
    return J

# Inicializar theta (parámetros)
theta = np.zeros(X_ready.shape[1])

# Definir parámetros del descenso por gradiente
alpha = 0.01
num_ite = 500

# Función de descenso por gradiente
def calcularDescensoGradiente(X, y, theta, alpha, num_ite):
    m = y.size
    J_historico = []
    
    for i in range(num_ite):
        theta = theta - (alpha / m) * (np.dot(X, theta) - y).dot(X)
        J_historico.append(calcularCosto(X, y, theta))
    
    return theta, J_historico

# Calcular theta usando descenso por gradiente
theta, J_historico = calcularDescensoGradiente(X_ready, y, theta, alpha, num_ite)
print(f"Los valores de theta calculados son: {theta}")
print(f"Costo final: {J_historico[-1]}")

# Graficar la convergencia del costo
plt.plot(np.arange(len(J_historico)), J_historico, lw=2)
plt.xlabel('Número de iteraciones')
plt.ylabel('Costo J')
plt.title('Convergencia del costo durante el descenso por gradiente')
plt.show()

# Predicción de ejemplo
y_pred = np.dot([1] + list(X_norm[0]), theta)
print(f"Predicción de ingreso: {y_pred}")

# Predicciones para todo el conjunto de datos
y_pred_all = np.dot(X_ready, theta)

# Gráfico de valores reales vs. predichos
plt.figure(figsize=(10, 6))
plt.scatter(y, y_pred_all, color='blue', edgecolor='k', alpha=0.7)
plt.plot([min(y), max(y)], [min(y), max(y)], color='red', linestyle='--', lw=2)
plt.xlabel('Valores reales de ingreso')
plt.ylabel('Valores predichos de ingreso')
plt.title('Gráfico de valores reales vs. predichos (Regresión Polinómica)')
plt.show()
